function exibirMensagem(){
    alert("Parabéns, você clicou no botão");
}