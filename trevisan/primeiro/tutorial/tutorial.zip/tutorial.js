var nome;
nome = prompt("Qual é seu nome?");
alert("Olá, " + nome);